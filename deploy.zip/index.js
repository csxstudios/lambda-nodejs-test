import express from 'express';

const app = express();

app.get('https://api.open-meteo.com/v1/forecast?latitude=38.84&longitude=-77.43&current_weather=true&temperature_unit=fahrenheit', (req, res) => {
    const data = req.json();
    console.log(data);
    response.send(data);
});
